class InvalidPhone(Exception):
    pass


class InvalidNetwork(Exception):
    pass


class InvalidCountry(Exception):
    pass
